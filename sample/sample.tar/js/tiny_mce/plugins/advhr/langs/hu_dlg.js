tinyMCE.addI18n('hu.advhr_dlg',{
width:"Sz\u00E9less\u00E9g",
size:"Magass\u00E1g",
noshade:"\u00C1rny\u00E9k n\u00E9lk\u00FCl"
});