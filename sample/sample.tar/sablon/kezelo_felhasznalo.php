<div class="tartalom">
    <h2>Felhasználó</h2>

    <?php 
    global $lnkpfx;
    $link = $lnkpfx."kezelo";

    if (isset($s->uzenet)) { ?>
    <fieldset  style="color: red;">
        <legend>Üzenet: </legend>
        
        <?php echo $s->uzenet ?>
    </fieldset>

    <?php } ?>
    <fieldset>
        <legend>Felhasználó adatai: </legend>
        <form method="post" action="<?php echo $link.'/felhasznalok/modosit/'.(int)$s->felhasznaloID ?>">
            <input name="modfelhasznalo" type="hidden" value="modfelhasznalo" >
            <?php if(@$fHiba=$s->felhasznaloHiba): ?>
                <p style="color: red;">
                <?php
                foreach($fHiba as $mezo => $hiba):
                   switch($mezo)
                   {
                       case'nev':
                            echo 'Kérem töltse ki a felhasználónév mezőt<br>';
                         break;
                       case'jelszo':
                            echo ($hiba=='*'?'Kérem töltse ki a jelszó mezőt<br>':'Két jelszó nem egyezik<br>');
                         break;
                       case'jelszo2':
                            echo 'Kérem töltse ki a második jelszó mezőt<br>';
                         break;
                   }
                endforeach ?>
                </p>
            <?php endif;
                $a=$s->felhasznaloAdat;    
            ?>
            <p>Felhasználónév:<br>
                <input name="nev"<?php echo ' value="'.htmlspecialchars(@$a['nev']).'"' ?>></p>
            <p>Jelszó (2x):<br>
                <input name="jelszo" type="password" style="margin-right:10px;"<?php echo ' value="'.htmlspecialchars(@$a['jelszo']).'"' ?>>
                <input name="jelszo2" type="password" style=""<?php if($fHiba) echo ' value="'.htmlspecialchars(@$a['jelszo2']).'"' ?>>
            </p>
            <p><input class="" type="submit" value="Módosítás" ></p>
        </form>
<?php /* ?>        
<script type="text/javascript" language="javascript">
    function setKepneve(file)
    {   var kepneve = document.getElementById("kepneve")
        kepneve.value = file.value
    }
</script> 
<?php */ ?>
    </fieldset>


<?php // */ ?>
    <br>
       <a href="<?php echo $link ?>/felhasznalok" style="margin: 10px;">vissza...</a>
</div>
