<?php 

class controller_keres
{
    var $keres;    
    
    function controller_keres()
    {
        global $lnkpfx;
        if($this->keres=$_POST['keresoSzo'])
        {   $this->files = glob('tartalom/*.htm');
            
        }
        else 
        {   
           
        }
    }
    function sablon()
    {
        echo '<div class="tartalom">';



        echo '<br>Keresőszó: "<b>'.$this->keres.'</b>"<br>';
        //var_dump($this->keres);
        echo "<br>";
        $talalatok = array();
        foreach ($this->files as $file)
        {
            $tartalom = ' '.strip_tags(file_get_contents($file)).' ';
            $pos = 0;
            $link = explode('/', $file);
            $link = explode('.', end($link));
            $link = current($link);
            while (($pos = stripos($tartalom,$this->keres,$pos+1)) !== false)
            {
                $talalat = substr($tartalom,$pos-45, 140);
                $elsoSp   = strpos ($talalat, ' ')+1;
                $utolsoSp = strrpos ($talalat, ' ');
                $talalat = substr($talalat, $elsoSp, $utolsoSp-$elsoSp);
                //echo '...&nbsp;'.$talalat."&nbsp;...<br><br>";
                if(stripos($talalat,$this->keres) !== false ) $talalatok[] = array($link, $talalat);
            }
         }
        echo count($talalatok).' találat: <br>';
        global $lnkpfx;
        
        $pos=0;
        foreach ($talalatok as $talalat)
        {
            echo ++$pos.'.
                <a href="'.$lnkpfx.$talalat[0].'">...'.$talalat[1].'...</a>
                <br><br>';
        }
        
        echo '</div>';
    }
    
} //class controller_keres
