<?php 
class controller_kezelo 
{
    function controller_kezelo($o)
	{
	    session_start();
	    $this->o = $o;

	    if (@$o[1] == 'kilep') unset($_SESSION['user']);
		if (@$_POST['user'] || isset($_GET['user']))   $this->belep();

	    if (!isset($_SESSION['user']))
	    {   $this->sablon_file = 'sablon/kezelo_belep';
	        return;
	    }

	    if (@$_GET['hosszuurl'])  $this->hosszuUrl();
	    if (@$_POST['tartalom'] or @$_POST['tartalomtorol'])  $this->saveTartalom();
	    if (@$_POST['fokepnev'])  $this->saveFoKep();
	    if (@$_POST['kepnev'])    $this->saveKep();
	    if (@$_POST['ujfelhasznalo'])  $this->ujFelhasznalo();
	    if (@$_POST['kepdesign'])    $this->saveDesign();
	    if (@$_POST['ujszolg'])   $this->ujSzolg();
	    if (@$_POST['szolgnevmod'])   $this->szolgNevMod();
	    if (@$_POST['ujtartalom'])    $this->ujTartalom();
	    if (@$_POST['webseo'])    $this->ujSeo();

	    if (@$o[1] == 'tartalmak' and isset($o[2]))
		{   $GLOBALS['javascript'][]='tiny_mce/tiny_mce.js';
		    $GLOBALS['javascript'][]='tiny_mce/tiny_init.js';
		    $this->sablon_file = 'sablon/kezelo_tartalmak';
		    return;
		}
		if (@$o[1] == 'delszolg' and isset($o[2]))  $this->delSzolg();
		if (@$o[1] == 'leszolg' and isset($o[2]))   $this->leSzolg();

		if (@$o[1] == 'kepek')
		{   if (@$o[2] == 'torol' and isset($o[3]))  $this->delKep($o[3]);
		    if (@$o[2] == 'masol' and isset($o[3]))  $_SESSION['copy_kep']=$o[3];
		    if (@$o[2] == 'beilleszt' and isset($o[3]))  $this->kepBeilleszt($o[3]);
		    if (@$o[2] == 'ures' and isset($o[3]))  $this->kepUres($o[3]);
		    $this->sablon_file = 'sablon/kezelo_kepek';
		    return;
		}
		if (@$o[1] == 'felhasznalok')
		{   require_once('felhasznalok.php');
		    //$this->felhasznalok=new felhasznalok;
		    /*
		    $f=new felhasznalo();
		    $f->nev='balint';
		    $f->jelszo='balint';
		    $f->save();
		    // */
		    /*
		    $f=new felhasznalok();
		    $f->del(0);
		    // */
		    $fhk = felhasznalok::get();
		    if (@$o[2] == 'torol' and isset($o[3]))
		    {   $f=new felhasznalo((int)$o[3]);
		        $f->del();
		        $this->uzenet='Felhasználót törölem.';
		    }
		    if (@$o[2] == 'modosit' and isset($o[3]))
		    {   $this->modFelhasznalo($o[3]);
		        return;
		    }
		    //print_r($fhk);
		    $this->sablon_file = 'sablon/kezelo_felhasznalok';
		    return;
		}

		$this->sablon_file = 'sablon/kezelo';
	}
	
	/* login */
	function belep()
	{
	    $a = $this->getPost();
      
      if(isset($_GET['user']) && isset($_GET['passw'])) {
				$a['user'] 	= $_GET['user'];
				$a['passw'] = $_GET['passw'];
			}
      
	    //var_dump($a);
	    if(!$a['user'] || !$a['passw']) return false;
	    $user = felhasznalok::keres($a['user'],$a['passw']);
	    //var_dump($user);
	    
	    if ($user)
	    {   $_SESSION['user'] = $user->getId();
	    }
	}
	
	function getDir($dir)
	{   
	    $docDir = getDir();
	    $dirs = array(
	        'tartalom' => 'tartalom'
	    );
        return isset($dirs[$dir]) ? $docDir.DIRECTORY_SEPARATOR.$dirs[$dir] : $docDir ;
	}
	
	function getPost()
	{
	    return (get_magic_quotes_gpc() ? array_map('stripslashes',$_POST) : $_POST);
	}
	
	function saveTartalom()
	{
	    $a = $this->getPost();
	    $file = getDir().DIRECTORY_SEPARATOR.'tartalom'.DIRECTORY_SEPARATOR.$a['nev'].'.htm';
	    //echo '<!--'.$file.'-->';
	    if (@$a['tartalomtorol'])  //torles
	    {
	        unlink($file);
	        @unlink(getDir().DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'tartalom'.DIRECTORY_SEPARATOR.$a['nev'].'.jpg');
	        header("Location: ?o=kezelo");
	        die;
	    }
	    if(file_exists($file))  //mentes
	    {   $dir = getDir();
	        if(file_put_contents($file, $a['tartalom']))
	            $this->uzenet = '"'.$a['nev'].'" tartalom módosításra került.<br>
	                Megtekintheti <a href="?o='.$a['nev'].'" target="masikablak">itt!</a>';
	        else 
	            $this->uzenet = 'Filerendszer hiba!<br>"'.
	                $a['nev'].'" megváltoztatása nem volt sikeres.';
	    }
	    
	}
	
	function ujTartalom()
	{
	    $a = $this->getPost();
	    if(ereg('[^a-z0-9_]', $a['ujtartalom'])) 
	    {   $this->ujTartalomHiba = 'karakter';
	        return;
	    }
	    $file = getDir().DIRECTORY_SEPARATOR.'tartalom'.DIRECTORY_SEPARATOR.$a['ujtartalom'].'.htm';
	    //echo '<!--'.$file.'-->';
	    if (file_exists($file))
	    {
	        $this->ujTartalomHiba = 'vanfile';
	        return;
	    }
	    file_put_contents($file, '');
	    header("Location: ?o=kezelo/tartalmak/".$a['ujtartalom']);
	    die;
	}
	
	function saveFoKep()
	{
	    $a = $this->getPost();
	    $uploadDir = getDir().DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'tartalom';
	    echo '<!--'.$uploadDir.'-->';
	      
        if (@$_FILES['kepfile']['name']) // ha feltoltott kepet
        {
            if ($_FILES['kepfile']['type'] == 'image/jpeg')
            {   if(move_uploaded_file($_FILES['kepfile']['tmp_name'], $uploadDir.DIRECTORY_SEPARATOR.$a['fokepnev'].'.jpg'))
                {   $this->uzenet = '"'.$a['fokepnev'].'" főkép módosításra került.';
                }
                else  $this->uzenet = 'A képfeltöltés során hiba lépett fel!';
            }
            else  $this->uzenet = 'Csak .jpg formátumú kép tölthető fel!';
        }
        else  $this->uzenet = 'Nem választott ki feltöltendő képet!';
	}
	
	function saveKep()
	{
	    $a = $this->getPost();
	    $uploadDir = getDir().DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'upload';
	    //echo '<!--'.$uploadDir.print_r($_FILES,true).'-->';  
        if (@$_FILES['kepfile']['name']) // ha feltoltott kepet
        {
            if(move_uploaded_file($_FILES['kepfile']['tmp_name'], $uploadDir.DIRECTORY_SEPARATOR.$a['kepneve']))
            {   $this->uzenet = '"'.$a['kepneve'].'" kép feltöltve.';
            }
            else
            {   $code = array(
					0=>"There is no error, the file uploaded with success",
					1=>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
					2=>"The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form",
					3=>"The uploaded file was only partially uploaded",
					4=>"No file was uploaded",
					6=>"Missing a temporary folder"); 
            	$this->uzenet = 'A képfeltöltés során hiba lépett fel! ['.$a['kepneve'].']<br>'.
            		'Hiba: '.@$code[$_FILES['kepfile']['error']].
            		'<!--'.$uploadDir.' '.print_r($_FILES,true).'-->';
            }
        }
        else  $this->uzenet = 'Nem választott ki feltöltendő képet!';
	}
	
	function delKep($file)
	{
	    $a = $this->getPost();
	    $uploadDir = getDir().DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'upload';
	    $delFile = $uploadDir.DIRECTORY_SEPARATOR.$file;
	    file_exists($delFile) and unlink($delFile);
	}
  /* design */
	function saveDesign()
	{
		$p=$this->getPost();
		$conf = getConf();
		$conf['design']['logo']=$p['d_logo'];
		$conf['design']['also']=$p['d_also'];
		$conf['design']['bg']=$p['d_bg'];
		$conf['design']['bg_css']=$p['d_css'];
		$conf['design']['a']=$p['d_a'];
		$conf['design']['a_fomenu']=$p['d_link'];
		$conf['design']['a_lab']=$p['d_lab'];
		$conf['design']['a_h']=$p['d_a_h'];
		$conf['design']['a_fomenu_h']=$p['d_link_h'];
		$conf['design']['a_lab_h']=$p['d_lab_h'];
		$conf['design']['copyright']=$p['d_copyright'];
		$conf['design']['ccolor']=$p['d_ccolor'];
		
		$this->saveConf($conf);
	}
	function kepBeilleszt($kep)
	{
		if($kep!='logo' and $kep!='also' and $kep!='bg') return;
		$conf = getConf();
		@$_SESSION['copy_kep'] and $conf['design'][$kep]=$_SESSION['copy_kep'];
	    $this->saveConf($conf);
	}
	function kepUres($kep)
	{
		if($kep!='logo' and $kep!='also' and $kep!='bg') return;
		$conf = getConf();
		$conf['design'][$kep]='';
	    $this->saveConf($conf);
	}
	
	function saveConf($conf)
	{   
	    $conf = serialize($conf);
	    $conf = base64_encode($conf);
	    file_put_contents(getDir().DIRECTORY_SEPARATOR.'conf'.DIRECTORY_SEPARATOR.'conf.php', $conf);
	    getConf(true);
	    
	}
	
  /* menu */
	function ujSzolg()
	{   
	    $a = $this->getPost();
	    $conf = getConf();
	    $conf['menu'][] = array($a['files'] => str_replace("&nbsp;"," ",$a['szolgnev']));
	    
	    $this->saveConf($conf);
	}
	
	function delSzolg()
	{
	    $a = $this->getPost();
	    $conf = getConf();
	    foreach ($conf['menu'] as $value)
	    {   if(key($value) == $this->o[2]) continue;
	        $ujconf[] = $value;
	    }
	    $conf['menu']=$ujconf;
	    $this->saveConf($conf);
	}
	
	function leSzolg()
	{
	    $a = $this->getPost();
	    $conf = getConf();
	    $ez = false;
	    foreach ($conf['menu'] as $value)
	    {   if(key($value) == $this->o[2])
	        {   $ez = $value;
	            continue;
	        }
	        $ujMenu[] = $value;
	        if ($ez)
	        {
	            $ujMenu[] = $ez;
	            $ez = false;
	        }
	    }
	    $conf['menu']=$ujMenu;
	    if($ez === false) $this->saveConf($conf);
	}
	
	function szolgNevMod()
	{
	    $a = $this->getPost();
	    $conf = getConf();
	    foreach ($conf['menu'] as $value)
	    {   if(key($value) == $a['szolgnevmod']) $ujMenu[] = array(key($value) => str_replace("&nbsp;"," ",$a['nev']));
	        else $ujMenu[] = $value;
	    }
	    //print_r($ujMenu);
	    $conf['menu']=$ujMenu;
	    $this->saveConf($conf);
	}

  /* SEO */
	function ujSeo()
	{
		$a = $this->getPost();
	    $conf = getConf();
	    //print_r($a);
	    $conf['seo']=array(
	    	'title' => $a['title'],
	    	'description' => $a['description'],
	    	'keywords' => $a['keywords'],
	    	'lang' => $a['lang'],
	    	'kovetok' => $a['kovetok'],
	    	'lnkpfx' => (@$a['rovidurl']?'':'?o=')
	    );
	    $this->saveConf($conf);
	}
	function hosszuUrl()
	{
		$conf = getConf();
	    $conf['seo']['lnkpfx'] = '?o=';
	    $this->saveConf($conf);
	}

  /* felhasznalok */
	function ujFelhasznalo()
	{
	    $a = $this->getPost();
	    if($hiba=$this->felhasznaloHiba=$this->ellenorFelhasznalo($a)) return false;

	    require_once('felhasznalok.php');
	    $f=new felhasznalo();
		$f->nev=$a['nev'];
		$f->jelszo=$a['jelszo'];
		$f->save();

	    $this->uzenet='Felhasználót felvettem.';
	}
	
	function modFelhasznalo($id)
	{
	    $this->felhasznaloID=$id;
	    $this->sablon_file = 'sablon/kezelo_felhasznalo';
	    $a = $this->getPost();
	    $f=$this->felhasznalo=new felhasznalo($id);
	    if(!$a)
	    {   $this->felhasznaloAdat=array(
	            'nev'=>$f->nev );
	        return;
	    }
	    else
	    {   $this->felhasznaloAdat=array(
	            'nev' => $a['nev'], 
	            'jelszo' => $a['jelszo'],
	            'jelszo2' => $a['jelszo2']);
	    }
		
		if($hiba=$this->felhasznaloHiba=$this->ellenorFelhasznalo($a)) return false;
	    
	    require_once('felhasznalok.php');
	    $f->nev=$a['nev'];
		$f->jelszo=$a['jelszo'];
		$f->save();

	    $this->uzenet='Felhasználót módosítottam.';
	}
	
	function ellenorFelhasznalo($a)
	{
	    $hiba = array();
	    if(!$a['nev']) $hiba['nev']='*';
	    if(!$a['jelszo'] ) $hiba['jelszo']='*';
	    elseif($a['jelszo']!=$a['jelszo2']) $hiba['jelszo']='!';
	    if(!$a['jelszo2']) $hiba['jelszo2']='*';
	    return $hiba;
	}

/*	
	function __destruct()
	{
	    print_r(getConf());
	}
*/	

		
} //class kezelo
