<div class="tartalom" style="padding-top: 20px;">
    <form method="post" action="">
        <table align="center">
            <tr><td style="text-align: right">Felhasználónév:</td><td><input type="text" name="user" id="be_user" value="" class="textBe" /></td></tr>
            <tr><td style="text-align: right">Jelszó:</td><td><input type="password" name="passw" id="be_passw" value="" class="textJsz" /></td></tr>
            <tr><td style="text-align: right"></td><td><input class="submitLogin" type="submit" value="OK" name="keres_kuld"/></td></tr>
        </table>
    </form>

</div>
