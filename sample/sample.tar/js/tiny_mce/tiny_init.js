tinyMCE.init({
    theme_advanced_toolbar_location : "top",
    theme_advanced_toolbar_align : "left",
    
    paste_auto_cleanup_on_paste : true,
    
    theme_advanced_buttons1 : "fontsizeselect,separator,bold,italic,underline,separator,forecolor,backcolor,separator,justifyleft,justifycenter,justifyright, justifyfull,separator,outdent,indent,blockquote,separator,bullist,numlist",
    theme_advanced_buttons2 : "cut,copy,paste,pasteword,separator,table,separator,sub,sup,separator,charmap,separator,link,unlink,separator,undo,redo,separator,image,code",
    theme_advanced_buttons3 : "",
    
    plugins : "table,paste",
    
    entities : "",
    language : "hu",

    mode : "textareas",
    theme : "advanced"
});
