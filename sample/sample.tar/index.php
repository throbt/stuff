<?php

error_reporting(E_ALL);
header('Content-Type: text/html; charset=utf-8');
function __autoload($class) 
{	include_once getDir()."/class/$class.php";
}
function getDir()
{   return $_SERVER['DOCUMENT_ROOT'];
}
function getConf($re = false)
{   static $conf;
    if(!$conf or $re)
    {   $conf = base64_decode(file_get_contents(getDir().'/conf/conf.php'));
    	$conf = unserialize($conf);
    	
		global $lnkpfx;
		$lnkpfx = $conf['seo']['lnkpfx'];
    }
    return $conf;
}
function get_ctrlr()
{	$o=explode('/', @$_GET['o']);
	$o[0]=='' and $o[0]='cegunkrol';
	if(preg_match('[^a-z0-9_]', $o[0])) {$ut='hiba.php'; $ctrl='hiba';}
	elseif(file_exists($ut='class/'.($ctrl='controller_'.$o[0]).'.php'));
	elseif(file_exists('tartalom/'.$o[0].'.htm'))  $ut='class/'.($ctrl='controller_tartalom').'.php';
	else  $ut='class/hiba.php' and $ctrl='hiba';
	include_once $ut;
	return new $ctrl($o);
}
function sablonkezelo($s, $file=false) 
{
	//error_reporting(E_ALL & ~ E_NOTICE);
	($file or @$s->sablon_file) ? (include ($file ? $file : @$s->sablon_file).'.php') : $s->sablon();
}

$c = get_ctrlr();
$javascript[]='meretezo.js';
sablonkezelo($c,'sablon/1');
