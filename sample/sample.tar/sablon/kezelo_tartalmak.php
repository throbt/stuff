<?php 
    global $lnkpfx;
    $link = $lnkpfx."kezelo";
 
/*    echo 'post:';
    print_r($_POST);
    echo 'files:';
    print_r($_FILES);  
*/
?>
<script type="text/javascript" language="javascript" charset="utf-8">
function tTorol(id) 
{
	if(confirm('"' + id + '"\nValóban törli a tartalmat?'))
	    return true
    return false
}
</script>
<div class="fokep" style="background: url(img/tartalom/<?php echo $s->o[2] ?>.jpg) no-repeat;">
    <input type="button" value="Vissza..." onClick="window.location='<?php echo $link ?>'" style="margin: 10px; float:right;">
    <div style="padding: 15px 30px">
        <div style="margin: 0 0 15px;"><span style="padding: 3px 5px; background: white; border: black 1px solid;">Új kép feltöltésse: (600x240) .jpg</span></div>
        <div>
        <form method="post" action="" enctype="multipart/form-data">
            <input name="fokepnev" type="hidden" value="<?php echo $s->o[2] ?>" />
            <p><input type="file" name="kepfile" /></p>
            <p><input class="" type="submit" value="Feltölt" /></p>
        </form>
        </div>
    </div>
</div>

<div class="tartalom">
<?php if (isset($s->uzenet)) { ?>
        <fieldset style="color: red">
            <legend>Üzenet: </legend>
            <?php echo $s->uzenet ?>
        </fieldset>
        <br />
<?php } ?>
    <h2>Szerkesztés: <?php echo $s->o[2] ?></h2>
    <form action="" method="post">
       <textarea name="tartalom" class="szerk">
       <?php
       /*
       $dir = $s->getDir('tartalom');
       $len = strlen($dir)+1;
       $files = glob($dir.'/*.htm');
       foreach ($files as $file)
       {
           $fileAzon = substr($file,$len, -4);
           echo '<a href="'.$link.'/tartalmak/'.$fileAzon.'">'.$fileAzon.'</a><br>';
       } */
       
       readfile('tartalom/'.$s->o[2].'.htm');
       
       ?>
       </textarea>
       <input type="submit" value="Módosít" style="float: left; margin: 10px 10px 10px 0">
       <input name="tartalomtorol" type="submit" value="Téma törlése" onClick="return tTorol('<?php echo $s->o[2] ?>')" style="float: left; margin: 10px 10px 10px 0">
       <input type="hidden" name="nev" value="<?php echo $s->o[2] ?>">
       <br>
       <a href="<?php echo $link ?>" style="margin: 10px; clear: left">vissza...</a>
    </form>
</div>
