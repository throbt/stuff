<?php 
class felhasznalok
{
    protected static $felh; #felhasznalok array
    protected static $file; #file utvonal
    
    function __construct()
    {
        self::get();
    }
    
    # felhasznalok tomb betoltese vagy ujratoltese ($re=true)
    static function get($re=false)
    {
        self::$file=getDir().DIRECTORY_SEPARATOR.'conf'.DIRECTORY_SEPARATOR.'felhasznalok.php';

        if(!self::$felh or $re)
        {   $felh = file_get_contents(self::$file);
		    self::$felh = unserialize(base64_decode($felh));
		}
        return self::$felh;
    }

    # felhasznalo keresese
    static function keres($nev,$jelszo)
    {
        self::get();
        foreach (self::$felh as $key => $egyF)
        {    if($nev==$egyF['nev'] && $jelszo==$egyF['jelszo']) return new felhasznalo($key);
        }
        return false;
    }

    # felhasznalok tomb mentese
    function save()
    {
        $felh = base64_encode(serialize(self::$felh));
	    file_put_contents(self::$file, $felh);
	    //print_r(self::$felh);
	    //getConf(true);
    }
    
    # egy felhasznalo modositasa
    function mod($id=null, $nev, $jelszo)
    {
        $felh=array(
            'nev'    => $nev,
            'jelszo' => $jelszo);

        if($id) self::$felh[$id]=$felh;
        else
        {   self::$felh[]=$felh;
            end(self::$felh);
            $key = key(self::$felh);
        }
        $this->save();
        return @$key;
    }
    
    # egy felhasznalo torlese
    function del($id)
    {
        unset(self::$felh[$id]);
        $this->save();
    }
}

class felhasznalo
{
    protected $id;
    protected $uj;
    public $nev;
    public $jelszo;
    
    function __construct($id=null)
    {
        if($id)
        {   $felh = felhasznalok::get();
            if (isset($felh[$id]))
            {   $this->id=$id;
                $this->nev=$felh[$id]['nev'];
                $this->jelszo=$felh[$id]['jelszo'];
            }
        }
        if (!$this->id)
        {    $this->uj=true;
        }
    }
    
    function getId() { return $this->id; }

    function save()
    {
        //echo ' {save} ';
        $fhk = new felhasznalok;
        $id = $fhk->mod($this->id,$this->nev,$this->jelszo);
        
        if ($id) $this->id=$id;
        //echo ' {/save} ';
    }
    
    function del()
    {
        $fhk = new felhasznalok;
        $fhk->del($this->id);
    }
}


