function ie6Elavult()
{
    var div
    div = document.getElementById('lapdiv')
    div.innerHTML = 
          '<div style="margin:10px 20px;">'
            + '<img src="style/ie6avult.jpg" style="float: left; margin: 0 20px 0px 0;">'
            + '<p><strong>Ön elavult böngészőt használ!</strong></p>'
            + '<p>Az Internet Explorer 6 böngésző támogatása megszűnt, gyártója a Microsoft Corporation maga is a lecserélését ajánlja, mert biztonsági kockázatokat is rejt.</p>'
            + '<p>Az Ön böngészője nem képes megfelelően megjeleníteni az oldalunkat, mert technológiailag elmaradott. Mi modernebb böngészőt ajánlunk helyette <a href="?o=technikai_informacio">itt.</a></p>'
        + '</div>'
        + div.innerHTML
}

ie6Elavult()
