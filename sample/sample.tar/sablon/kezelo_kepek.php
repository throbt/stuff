<div class="tartalom">
    <h2>Képek</h2>

    <?php 
    global $lnkpfx;
    $link = $lnkpfx."kezelo";
    if (isset($s->uzenet)) { ?>
    <fieldset  style="color: red;">
        <legend>Üzenet: </legend>
        
        <?php echo $s->uzenet ?>
    </fieldset>

    <?php } ?>
    <fieldset>
        <legend>Feltöltött képek: </legend>
        <table border="0" cellpadding="5" cellspacing="0">
        <?php 
        $files = glob(getDir().'/img/upload/*');
        foreach ($files as $file)
        {
            $fileNev = explode('/', $file);
            $fileNev = end($fileNev);
            echo '
            <tr>
                <td><img src="img/upload/'.$fileNev.'" style="max-width:100px; max-height:100px"></td>
                <td>'.$fileNev.'</td>
                <td><a href="'.$link.'/kepek/torol/'.$fileNev.'" onclick="return confirm(\'Valóban törli?\')">Töröl</a></td>
                <td><a href="'.$link.'/kepek/masol/'.$fileNev.'">Másol</a></td>
            </tr>';
        }
        //print_r($_SERVER);
        ?> 
        </table>
        
<script type="text/javascript" language="javascript">
    function setKepneve(file)
    {   var kepneve = document.getElementById("kepneve")
        kepneve.value = file.value
    }
</script> 
    </fieldset>
    <fieldset>
        <legend>Új kép feltöltése: </legend>
        <form method="post" action="<?php echo $link ?>/kepek" enctype="multipart/form-data">
            <input name="kepnev" type="hidden" value="kepnev" >
            <p><input type="file" name="kepfile" onChange="setKepneve(this)"></p>
            <p>Kép neve a szerveren:<br>
                <input name="kepneve" id="kepneve" value="" style="width: 100%">
            </p>
            <p><input class="" type="submit" value="Feltölt" ></p>
        </form>
    </fieldset>

    <fieldset>
        <legend>Design </legend>
        <form method="post" action="<?php echo $link ?>/kepek" enctype="multipart/form-data">
            <input name="kepdesign" type="hidden" value="kepdesign" >
            <table class="kepdesign" border="0" cellpadding="5" cellspacing="0">
            	<?php if(isset($_SESSION['copy_kep'])){ ?>
            	<tr><td>Vágólap:</td>
            		<td><a href="<?php echo 'img/upload/'.$_SESSION['copy_kep'] ?>"><?php echo $_SESSION['copy_kep'] ?></a>
            		</td><td></td><td></td></tr>
            	<?php }
            		$beill=$link.'/kepek/beilleszt/';
            		$ures =$link.'/kepek/ures/';
            		$conf=getConf(); ?>
            	<tr>
            		<td>Logo:</td>
            		<td><input name="d_logo" id="d_logo" value="<?php echo $conf['design']['logo'] ?>"></td>
            		<td><a href="<?php echo $ures ?>logo" onclick="return confirm('Valóban törli?')">Töröl</a></td>
            		<td><a href="<?php echo $beill ?>logo">Beilleszt</a></td></tr>
            	<tr>
            		<td>Alsó kép:</td>
            		<td><input name="d_also" id="d_also" value="<?php echo @$conf['design']['also'] ?>"></td>
        			<td><a href="<?php echo $ures ?>also" onclick="return confirm('Valóban törli?')">Töröl</a></td><td><a href="<?php echo $beill ?>also">Beilleszt</a></td></tr>
            	<tr>
            		<td>Háttér:</td>
            		<td><input name="d_bg" id="d_bg" value="<?php echo @$conf['design']['bg'] ?>"></td>
            		<td><a href="<?php echo $ures ?>bg" onclick="return confirm('Valóban törli?')">Töröl</a></td>
            		<td><a href="<?php echo $beill ?>bg">Beilleszt</a></td></tr>
				<tr>
					<td>Háttér CSS:</td>
					<td colspan="3"><input name="d_css" id="d_css" value="<?php echo @$conf['design']['bg_css'] ?>" style="width:100%"></td></tr>
					<tr>
					<td>Háttér minták:</td>
					<td colspan="3">
						<input type="button" value="Fönt"	
							title="Fönt helyezkedik el, és vízszintesen ismétlődik"
							onclick="document.getElementById('d_css').value='repeat-x fixed center top white'" />
						<input type="button" value="Lent"	
							title="Lent helyezkedik el, és vízszintesen ismétlődik"
							onclick="document.getElementById('d_css').value='repeat-x fixed center bottom white'" />
						<input type="button" value="Közép"	
							title="Középre van igazítva és függőlegesen ismétlődik"
							onclick="document.getElementById('d_css').value='repeat-y fixed center top white'" />
						<input type="button" value="Mozaik"	
							title="Teljes képernyőt betöltő mozaik"
							onclick="document.getElementById('d_css').value='repeat fixed center center white'" />
					</td></tr>
				<tr><td colspan="4">&nbsp;</td></tr>
				<tr>
					<td>Link szín:</td>
					<td colspan="3">
						<input name="d_a" id="d_a" value="<?php echo @$conf['design']['a'] ?>" style="width:45%;margin-right:10px;">
						<input name="d_a_h" id="d_a_h" value="<?php echo @$conf['design']['a_h'] ?>" style="width:45%"></td></tr>
				<tr>
					<td>Menü szín:</td>
					<td colspan="3"><input name="d_link" id="d_link" value="<?php echo @$conf['design']['a_fomenu'] ?>" style="width:45%;margin-right:10px;">
					<input name="d_link_h" id="d_link_h" value="<?php echo @$conf['design']['a_fomenu_h'] ?>" style="width:45%"></td></tr>
				<tr>
					<td>Láb-link szín:</td>
					<td colspan="3"><input name="d_lab" id="d_lab" value="<?php echo @$conf['design']['a_lab'] ?>" style="width:45%;margin-right:10px;">
					<input name="d_lab_h" id="d_lab_h" value="<?php echo @$conf['design']['a_lab_h'] ?>" style="width:45%"></td></tr>
				<tr><td colspan="4">&nbsp;</td></tr>
				<tr>
					<td>Copyright:</td>
					<td colspan="3"><input name="d_copyright" id="d_copyright" value="<?php echo @$conf['design']['copyright'] ?>" style="width:100%"></td></tr>
				<tr>
					<td>Copyright szín:</td>
					<td colspan="3"><input name="d_ccolor" id="d_ccolor" value="<?php echo @$conf['design']['ccolor'] ?>" style="width:45%"></td></tr>
            </table>
            <p><input class="" type="submit" value="Módosít" ></p>
        </form>
    </fieldset>
    <br>
       <a href="<?php echo $link ?>" style="margin: 10px;">vissza...</a>
</div>
