<div class="tartalom">
<!--
<?php 
    print_r($_POST);
    print_r($_FILE);  
?>
-->
    <h2>Kezelő</h2>
    <?php 
    global $lnkpfx;
    $link = $lnkpfx."kezelo";
    if (isset($s->uzenet)) { ?>
        <fieldset  style="color: red;">
            <legend>Üzenet: </legend>
            
            <?php echo $s->uzenet ?>
        </fieldset>
        <br />
    <?php } ?>
<script type="text/javascript" language="javascript" charset="utf-8">
function menuTorol(id) 
{
	if(confirm('"' + id + '"\nValóban törli a menüpontot?'))
	    window.location.href='<?php echo $link ?>/delszolg/'+id;
    return false
}
</script>
   <fieldset>
    <legend>Tartalmak</legend>
   <?php
   
   $dir = $s->getDir('tartalom');
   $len = strlen($dir)+1;
   $files = glob($dir.'/*.htm');
   $fajlok = array();
   foreach ($files as $file)
   {
       $fileAzon = substr($file,$len, -4);
       echo '<a href="'.$link.'/tartalmak/'.$fileAzon.'">'.$fileAzon.'</a><br>';
       $fajlok[] = $fileAzon;
   } ?>
   <hr>
   <form action="<?php echo $link ?>" method="post">
        <?php 
        if(@$s->ujTartalomHiba == 'karakter')
            echo '<span style="color:red">Csak ékezet nélküli betű, szám és _ használható a névnél!</span><br>';
        if(@$s->ujTartalomHiba == 'vanfile')
            echo '<span style="color:red">Ez a tartalom már létezik!</span><br>' ?>
     Új tartalom felvétele: <input name="ujtartalom">
   </form>
   </fieldset>
<?php /* ?>
   <fieldset>
    <legend>Főképek</legend>
    <form method="post" action="<?php echo $link ?>" enctype="multipart/form-data">
        <p>
            <select name="fokepnev">
            <?php foreach ($fajlok as $file) 
            { 
                echo '<option>'.$file.'</option>';
            } ?>
            </select>
        </p>
        <p><input type="file" name="kepfile" /></p>
        <p><input class="" type="submit" value="küldés" /></p>
    </form>
   </fieldset>
<?php */ ?>
   <fieldset>
    <legend>Képek és design</legend>
    <a href="<?php echo $link ?>/kepek">Képkezelő és design...</a><br>
   </fieldset>
   <fieldset>
    <legend>Felhasználók</legend>
    <a href="<?php echo $link ?>/felhasznalok">Felhasználók kezelése...</a><br>
   </fieldset>
   <fieldset>
    <legend>Szolgáltatások menü</legend>
    
        <?php 
        $conf = getConf();
        $menu = $conf['menu'];
        $mElem = array();
        if($menu)
        {   end($menu);
            $utolso = key($menu);
		    foreach ($menu as $key => $value)
		    { ?>  
		    <div style="margin: 5px 0; background: #eeeeee; padding:5px">
		    <form action="<?php echo $link ?>" method="post">
		        <input type="hidden" name="szolgnevmod" value="<?php echo key($value) ?>">
		        <?php echo key($value) ?>:<br>
		        <input name="nev" value="<?php echo current($value) ?>" style="width:95%">
		        <div style="text-align: right">
		            <?php if ($key != $utolso) { ?><a href="<?php echo $link ?>/leszolg/<?php echo key($value) ?>">Lejjebb</a> &nbsp;<?php } ?>
		            <a href="<?php echo $link ?>/delszolg/<?php echo key($value) ?>" onClick="return menuTorol('<?php echo key($value) ?>')">Töröl</a> &nbsp; 
		        </div>
		    </form>
		    </div>
		    <?php    $mElem[] = key($value);
		    }
		} ?>
    <form action="<?php echo $link ?>" method="post">
	    <br>Új menüpont felvétele:<br><br>
	    <select name="files">';
	    <?php foreach ($fajlok as $file)
        {
           if (in_array($file,$mElem)) continue;
           echo '<option>'.$file.'</option>';
        } ?>
        </select>&nbsp;
        neve: <input name="szolgnev" value="">&nbsp;
        <input type="submit" name="ujszolg" value="Felvesz">
	
    </form>
   </fieldset>

   <fieldset>
    <legend>SEO</legend>
    
        <?php 
        $seo = $conf['seo'];
        ?>
    <form action="<?php echo $link ?>" method="post" class="webseo">
	    
        <label>Cím</label><input name="title" value="<?php echo @$seo['title'] ?>">
        <label>description</label><input name="description" value="<?php echo @$seo['description'] ?>">
        <label>keywords</label><input name="keywords" value="<?php echo @$seo['keywords'] ?>">
        <label>lang</label><input name="lang" style="width:100px;" value="<?php echo (@$seo['lang']?$seo['lang']:'hu') ?>">
        <label>Követők:</label><textarea name="kovetok" style="width:300px;height:160px"><?php echo @$seo['kovetok'] ?></textarea>
        <label>Rövid URL</label><input type="checkbox" name="rovidurl" style="width:auto" <?php echo (@$seo['lnkpfx']?'':' checked="checked"') ?>>
        <label>&nbsp;</label><input type="submit" name="webseo" value="Felvesz" style="width:100px;">
	
    </form>
   </fieldset>
   
    <br><a href="<?php echo $link ?>/kilep" >Kilépés...</a>
    <?php //print_r($_POST);print_r($_SERVER) ?>
   
</div>
