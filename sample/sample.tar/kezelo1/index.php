<?php
$link=$_SERVER['HTTP_HOST'].substr($_SERVER['REQUEST_URI'],0,-7).'?o=kezelo&hosszuurl=true';
header('Location: http://'.$link);
?>
