<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title><?php $conf = getConf(); echo $conf['seo']['title'] ?></title>
	<meta name="author" content="Szalai Bálint +36303922611">
	<meta name="keywords" lang="<?php echo $conf['seo']['lang'] ?>" content="<?php echo $conf['seo']['keywords'] ?>">
	<meta name="description" lang="<?php echo $conf['seo']['lang'] ?>" content="<?php echo $conf['seo']['description'] ?>">
	<meta name="ROBOTS" content="INDEX, FOLLOW">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="content-style-type" content="text/css">
	<meta http-equiv="content-language" content="<?php echo $conf['seo']['lang'] ?>">
	<meta name="language" content="<?php echo $conf['seo']['lang'] ?>" />

	<base href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/">
	<link type="text/css" href="style/style.css" rel="stylesheet">
	<!--[if IE 7]>
		<link type="text/css" href="style/style7.css" rel="stylesheet">
	<![endif]-->
	<!--[if IE 6]>
		<link type="text/css" href="style/style6.css" rel="stylesheet">
	<![endif]--> 

	<style type="text/css" media="screen">
		<?php echo (@$conf['design']['bg_css']?'body {background:'.@$conf['design']['bg_css'].'}':'').'
		'.(@$conf['design']['bg']?'body {background-image:url(img/upload/'.@$conf['design']['bg'].')}':'').'
		'.(@$conf['design']['a']?'a {color:'.@$conf['design']['a'].'}':'').'
		'.(@$conf['design']['a_h']?'a:hover {color:'.@$conf['design']['a_h'].'}':'').'
		'.(@$conf['design']['a_fomenu']?'a.fomenu {color:'.@$conf['design']['a_fomenu'].'}':'').'
		'.(@$conf['design']['a_fomenu_h']?'a.fomenu:hover {color:'.@$conf['design']['a_fomenu_h'].'}':'').'
		'.(@$conf['design']['a_lab']?'div.labjegyzet a {color:'.@$conf['design']['a_lab'].'}':'').'
		'.(@$conf['design']['a_lab_h']?'div.labjegyzet a:hover {color:'.@$conf['design']['a_lab_h'].'}':''); ?> 
	</style>
<?php
global $lnkpfx,$javascript;
if (isset($javascript)) foreach ($javascript as $value)
    echo '
    <script type="text/javascript" src="js/'.$value.'"></script>'; ?>
</head>
<body>

	<div class="alap" id="idid">
		<div class="bal">
			<?php if($conf['design']['logo']){ ?><img src="img/upload/<?php echo $conf['design']['logo'] ?>" class="www_logo" ><?php } ?>
			<ul id="fomenu">
				<?php foreach ($conf['menu'] as $value)  echo '
                <li><a class="fomenu" href="'.$lnkpfx.key($value).'">'.current($value).'</a></li>'; ?>
			</ul>
			<div class="nyelv">
			    <!--<a href=""><img src="style/hu.jpg" border="0" alt="HU"></a>
			    <a href=""><img src="style/en.jpg" border="0" alt="EN"></a>-->
			</div>
			
		</div>
		<div id="alsodiv">
		    <?php if(@$conf['design']['also']){ ?><img src="img/upload/<?php echo @$conf['design']['also'] ?>" border="0" alt="HU" onLoad="meretezo()"><?php } ?>
		</div>
<?php /* ?>
		<div class="kereso">
		    <form action="<?php echo $lnkpfx ?>keres" method="post">
    		    <input class="keresosav" type="text" name="keresoSzo" value="Keresés..." onfocus="this.value='';">
    		    <input class="keresogomb" type="submit" value="&nbsp;&nbsp;" id="" />
    		</form>
        </div>
<?php */ ?>
		<div class="lap_arnyek_top">&nbsp;</div>
		<!--<div class="lap_arnyek_top2"></div>-->
		<div class="lap_arnyek">
			<div class="lap" id="lapdiv">

			<?php sablonkezelo($s) ?>

<!--[if IE 6]>
    <script type="text/javascript" src="js/ie6.js"></script>
<![endif]--> 

			</div>
			<script type="text/javascript" language="javascript" charset="utf-8">meretezo2()</script>
		</div>
		<div class="lap_arnyek_bottom">&nbsp;</div>
		<div class="labjegyzet"<?php if(@$conf['design']['ccolor']) echo 'style="color: '.$conf['design']['ccolor'].'"' ?>>
		    <a href="<?php echo $lnkpfx ?>termsofuse">Terms of Use</a>
		    
		    <div style="color: <?php echo @$conf['design']['ccolor'] ?>; padding: 8px 0 20px;"><?php echo @$conf['design']['copyright'] ?></div>
		</div>
	</div>

<?php echo $conf['seo']['kovetok'] ?>
<?php //echo print_r($_SERVER); ?>

</body>
</html>
