<?php 

class hiba
{
	function hiba($o)
	{
	    //echo 'Hiba!<br>';
		//print_r($o);
		//die;
	}
	
	function sablon()
	{
	?>
	<div class="tartalom" style="text-align: center; font-size: 20px; padding-top: 10%">
        A keresett oldal nem található!
    </div>
	<?php
	}
	
} //class 
