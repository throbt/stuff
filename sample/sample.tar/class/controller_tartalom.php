<?php 
class controller_tartalom 
{
	function controller_tartalom($o)
	{
        $this->nev = $o[0];
	}
	
	function sablon()
	{
?>

<div class="fokep" style="background: url(img/tartalom/<?php echo $this->nev ?>.jpg) no-repeat;"></div>
<div class="tartalom">
<?php readfile('tartalom/'.$this->nev.'.htm'); ?>        
</div>

<?php

	}
	
} //class tartalom
